<?php

session_start();

if (isset($_SESSION['SESS_USERNAME'])) 
{
  $user_name=$_SESSION['SESS_USERNAME'];
}

?>
<html>
<head>
      <title>LIVE ART</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<style>
body{
    background-image:url(Images/bg3.jpg);
}
</style>

</head>
<body>
<header>
<img src="Images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="Images/user.jpg" alt="user" class="user_image">
<div class="link">

<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}



?>

</div>


<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>
<h2 class="h2">Live Art</h2>
</header>
<div id="navbar" style="margin-top:20px;">
<hr id="hr" style="margin-top:-20px;">
<ul class="nav" style="background-color:darkslategray;">
  <li><a href="Homepage.php">Home</a></li>
  <li><a href="Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="../Ranul/Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">
</div>

<div id="artists">
<h1>Artists</h1>
</div>

<div id="img">
<img src="images/martine.jpg" alt="Martine Lafevre" width="200px" height="150px">
</div>
<div class="name">
<a href="#"><b>Martine lafevere</b></a>
</div>
<div id="img">
<img src="images/andrew.jpg" alt="Andrew Voron" width="200px" height="150px">
</div>
<div class="name">
<a href="#"><b>Andrew Voron</b></a>
</div>
<div id="img">
<img src="images/beata.jpg" alt="Beata Duatray" width="200px" height="150px">
</div>
<div class="name">
<a href="#"><b>Beata Dautray</b></a>
</div>
<div id="img">
<img src="images/cheker.jpg" alt="CHeKER" width="200px" height="150px">
</div>
<div class="name" style="margin-left:-140px;">
<a href="#"><b>CHeKER</b></a>
</div>
<div id="img">
<img src="images/anne.jpg" alt="Anne ne Degroni" width="200px" height="150px">
</div>
<div class="name">
<a href="#"><b>Anne ne Degroni</b></a>
</div>

<div id="i">
<a href="#" style="color:red;"><i class="fa fa-info-circle" style="font-size:20px;"></i>Sponsored Artworks</a>
</div>

<div id="a-z">
<ul>
  <li><a href="#">A</a></li>
  <li><a href="#">B</a></li>
  <li><a href="#">C</a></li>
  <li><a href="#">D</a></li>
  <li><a href="#">E</a></li>
  <li><a href="#">F</a></li>
  <li><a href="#">G</a></li>
  <li><a href="#">H</a></li>
  <li><a href="#">I</a></li>
  <li><a href="#">J</a></li>
  <li><a href="#">K</a></li>
  <li><a href="#">L</a></li>
  <li><a href="#">M</a></li>
  <li><a href="#">N</a></li>
  <li><a href="#">O</a></li>
  <li><a href="#">P</a></li>
  <li><a href="#">Q</a></li>
  <li><a href="#">R</a></li>
  <li><a href="#">S</a></li>
  <li><a href="#">T</a></li>
  <li><a href="#">U</a></li>
  <li><a href="#">V</a></li>
  <li><a href="#">W</a></li>
  <li><a href="#">X</a></li>
  <li><a href="#">Y</a></li>
  <li><a href="#">Z</a></li>
</ul>
</div>
<div class="line"></div>

<div class="combo">
<select class="selectbox">
  <option value="Worldwide">Worldwide</option>
</select>
</div>
<div id="search">
<form name="search">
<input type="text" name="text" placeholder="Search" style="height:40px;width=:220px;border:2px inset;">
<i class="fa fa-search" onclick="return validateSearch()" style="font-size:24px;margin-left:0px;color:#4CAF50;cursor:pointer;"></i>
</form>
</div>
<div class="image" style="clear:both;">
<img src="images/luce.jpg" alt="Luce" width="220px" height="170px">
</div>
<div class="image">
<img src="images/angot.jpg" alt="Luce" width="220px" height="170px">
</div>
<div class="image">
<img src="images/nanouv.jpg" alt="Luce" width="220px" height="170px">
</div>
<div class="image">
<img src="images/spaki.jpg" alt="Luce" width="220px" height="170px">
</div>

<form method="POST">

<div class="textarea" style="clear:both;">
<br><br>
<div class="para">
<span value="Luce" name="name"><b>Luce</b></span>
</div>

<input type="submit" value="+Follow" class="button" name="follow1">
<br><br>
<div class="city">
Slovakia
</div>
</div>

<div class="textarea">
<br><br>
<div class="para">
<b>Angot</b>
</div>
<input type="submit" value="+Follow" class="button" name="follow2">
<br><br>
<div class="city">
France
</div>
</div>

<div class="textarea">
<br><br>
<div class="para">
<b>Nanouv</b>
</div>
<input type="submit" value="+Follow" class="button" name="follow3">
<br><br>
<div class="city">
Italy
</div>
</div>

<div class="textarea">
<br><br>
<div class="para">
<b>Spaki</b>
</div>
<input type="submit" value="+Follow" class="button" name="follow4">
<br><br>
<div class="city">
Serbia
</div>
</div>

</form>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

<script src="javascript.js"> </script>

</body>
</html>


<?php

require 'config.php';


if (isset($_POST['follow1']))
{ 

  if (!empty($_SESSION['SESS_USERNAME'])) 
  {
       $name='Luce';
       $country='Slovakia';


       $sql="INSERT INTO following VALUES ('$user_name','$name','$country','".date("Y-m-d")."')";

       if (mysqli_query($con,$sql)) 
       {
          echo "You are now following".$name;
       }
      
   }
   else
   {
    //header('location: ../Suthakar/login.php');
   }
}

if (isset($_POST['follow2']))
{ 

  if (!empty($_SESSION['SESS_USERNAME'])) 
  {
       $name='Angot';
       $country='France';


       $sql="INSERT INTO following VALUES ('$user_name','$name','$country','".date("Y-m-d")."')";

       if (mysqli_query($con,$sql)) 
       {
          echo "You are now following".$name;
       }
      
   }
   else
   {
    //header('location: ../Suthakar/login.php');
   }
}
if (isset($_POST['follow3']))
{ 

  if (!empty($_SESSION['SESS_USERNAME'])) 
  {
       $name='Angot';
       $country='France';


       $sql="INSERT INTO following VALUES ('$user_name','$name','$country','".date("Y-m-d")."')";

       if (mysqli_query($con,$sql)) 
       {
          echo "You are now following".$name;
       }
      
   }
   else
   {
    //header('location: ../Suthakar/login.php');
   }
}
if (isset($_POST['follow4']))
{ 

  if (!empty($_SESSION['SESS_USERNAME'])) 
  {
       $name='Angot';
       $country='France';


       $sql="INSERT INTO following VALUES ('$user_name','$name','$country','".date("Y-m-d")."')";

       if (mysqli_query($con,$sql)) 
       {
          echo "You are now following".$name;
       }
      
   }
   else
   {
    //header('location: ../Suthakar/login.php');
   }
}

?>
<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
$user_name=$_SESSION['SESS_USERNAME'];

?>
<html>
<head>
      <title>LIVE ART</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<style>
body{
   background-image:url(Images/bg3.jpg);
}
</style>
</head>

<body>
<header>
<img src="Images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="Images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}



?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>

<div id="navbar" style="margin-top:20px;">
<hr id="hr" style="margin-top:-20px;">
<ul class="nav" style="background-color:black;">
  <li><a href="Homepage.php">Home</a></li>
  <li><a href="Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="../Ranul/Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">
</div>

<div id="here">
<h2>Here's your order confirmation</h2>
</div>
<hr id="hr" style="margin-top: 30px;">

<div class="hello">
<p>Hello ###User,<br><br>
   Here is a summary of your recent order. You can also view your <a href="#">updated orders</a> details in My LIVE ART.<br>
</p>
</div>

<div class="Thank">
<p><b>Thank You for shopping on</b> LIVE ART</p>
</div>

<div id="goto">
<input type="submit" value="Go to order details" style="background-color:green;width:150px;padding:5px;border-radius:10px;border:none;">
</div>

<div class="order">
<h3 style="margin-left:20px;">Order Details</h3>
<div style="border-bottom-style:solid;width:100%"></div>
<p style="margin-left:20px;">You completed checkout on 22 June 2018</p><br>
<p style="float:left;margin-left:20px;margin-top:0px;">Sent to Yellowspeed</p>
<p style="float:left;margin-top:0px;margin-left:80px;">Payment Details</p>
<p style="float:left;margin-top:0px;margin-left:100px;"><b>TOTAL</b></p>
<p style="float:left;margin-left:20px;margin-top:0px;">258,Dukee road,<br>Hong Konk</p>
<p style="float:left;margin-top:0px;margin-left:105px;">Paypal</p>
<p style="float:left;margin-top:0px;margin-left:165px;"><b>3.28$</b></p>
</div>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

</body>
</html>
<?php
session_start();

?>
<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<style>
body{
   background-image:url(Images/bg3.jpg);
}
</style>
</head>

<body>


<header>
<img src="Images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br> <p><center style="color:red;">
<?php
if(isset($_GET['message']))
{
echo $_GET['message'];
}
?></center>
</p>
<img src="Images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}



?>
</div>


<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>
<h2 class="h2">Live Art</h2>
</header>
<div id="navbar" style="margin-top:20px;">
<hr id="hr" style="margin-top:-20px;">
<ul class="nav" style="background-color:darkslategray;">
  <li><a href="Homepage.php">Home</a></li>
  <li><a href="Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="../Ranul/Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">
</div>




<div class="left_sidebar">
<h2 style="color:white;">Media Types</h2>
<ul class="ul">
    <li><a href="#all">All</a></li>
    <li><a href="#ilustration">Illustration</a></li>
    <li><a href="#photo">Photo</a></li>
    <li><a href="#animation">Animation</a></i>
    <li><a href="#anticimages">Antic Images</a></li>
    <li><a href="#drawings">Drawings</a></li>
    <li><a href="#fineart">Fine art</a></li>
</ul>
<br>
<h2 style="color:white;">Image Size</h2>
<ul class="ul">
    <li><a href="#all">All</a></li>
    <li><a href="#small">Small</a></li>
    <li><a href="#medium">Medium</a></li>
    <li><a href="#large">Large</a></i>
    <li><a href="#resizeable">Resizeable</a></li>
</ul>
<br>
<select class="selectbox">
  <option value="Add to Cart">Add to Cart</option>
</select><br>
<select class="selectbox">
  <option value="Extras">Extras</option>
</select>
</div>
<div class="left_vertical"></div>


<div class="right_sidebar">
<form name="search" onsubmit="return validateSearch()">
<input type="text" name="text" style="border-radius:5px;">
<input type="submit" value="Search" style="width:80px;border-radius:5px;" onsubmit="return validsearch()">
</form>

<div class="text1">
<p  style="margin-top: 6px;"><b>Free Shipping</b></p>
</div>
<div class="text2">
<p style="margin-top:10px;">Free deliver on all orders above $100</p>
</div>
<br>
<div class="text1">
<p style="margin-top:8px;"><b>Money Back Guarantee</b></p>
</div>
<div class="text2">
<p style="margin-top:10px;">We offer 15 days easy return</p>
</div>
<br>
<div class="text1">
<p style="margin-top:8px;"><b>Online Support 24/7</b></p>
</div>
<div class="text2">
<p style="margin-top:10px;">Our operators are available 24/7</p>
</div>
<br><br><br>
<div class="text3">
<p style="margin-top:5px;">Recent News<br><br>
The British Museum Wants to Borrow
That 'Baby Trump' Balloon-But it's Got Competition<br><br>
The director of the Museum of London thinks
it should be preserved for the nation but activists
say their priority is to fly the blimp wherever
the US President travels.<br><br>
Naomi Rea,July 19,2018</p>
</div>
<br><br>
<div id="https">
<a href="https://www.liveart.com">https://www.liveart.com</a>
</div>

</div>
<div class="right_vertical"></div>



<div class="h">
<h2 class="hborder" style="color:white;">Featured Products</h2>
</div>
<br>

<div class="img1">
<img src="images/art1.png" alt="Image_1" width="375px" height="200px">
</div>
<div class="img2">
<img src="images/art2.jpg" alt="Image_2" width="375px" height="200px">
</div>
<br><br><br><br>

<div class="best">
<h2 class="hborder" style="color:white;">Best Sellers</h2>
</div>
<br><br><br><br><br>

<div class="img3">
<img src="images/art3.jpg" alt="Image_3" width="375px" height="200px">
</div>
<div class="img4">
<img src="images/art4.jpg" alt="Image_4" width="375px" height="200px">
</div>
<div class="p1">
<p><b>Text Design</b></p>
</div>
<div class="p2">
<p><b>Smart Paintings</b></p>
</div>
<div class="img5">
<img src="images/art5.jpeg" alt="Image_5" width="375px" height="200px">
</div>
<div class="img6">
<img src="images/art6.jpg" alt="Image_6" width="375px" height="200px">
</div>
<div class="p3">
<p><b>Texture Pattern</b></p>
</div>
<div class="p4">
<p><b>Easy Paintings</b></p>
</div>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

<script src="javascript.js"> </script>

</body>
</html>
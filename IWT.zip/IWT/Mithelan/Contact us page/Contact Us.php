<?php

session_start();

?>

<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<script src="formvalid.js"></script>

</head>

<header>
<img src="Images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="Images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}



?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>
<h2 class="h2">Live Art</h2>
</header>

<hr id="hr" style="margin-top:-20px;">
<ul class="nav" style="background-color:darkslategray;">
<b><li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li></b>
</ul>
<hr id="hr">

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

<h3 style="color:white"><u><b>Contact US</h3></u></b>


  <div id="textbox">
  <p class="alignleft">
  

<style>
   #text-position {
      position: absolute;
      bottom: 80px;
      text-align: center;
      width: 30%;
}
</style>

<font color="red">

    <div id="text-position"><i style="font-size:24px" class="fa">&#xf095;</i>
     Call</p>
     <div id="text-position"></p>
    </div></font>
     <br>


<p style="color:gold;"><b><i>011-288-8888</i></b></p>

<p style="color:gold;"><b><i>077-777-7777</i></b></p>

<p style="color:red;"> FAQ:</p>   
<p style="color:gold;"><b><u><i style="font-size:24px" class="fa">&#xf059;</i> Check our Frequently Asked Question</b></u></p><br>

<font color="red"><p>My account:</p>

</font>
   

<span style="cursor:pointer">
 <p style="color:gold;"><b><u> <i style="font-size:24px" class="fa">&#xf2be;</i> Access your account </p><b/b></u>
</span><br>

<div class="cusInfo">
<font color="gold"><p><i style="font-size:24px" class="fa fa-chat">&#xf1d7</i>
 <p id="msg">Send us a message<br> We'd love to hear from you</p></font>
</div>

<style>
input[type=tt], select {
    width: 150%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 1px 1px;
    border: none;
    border-radius: 2px;
    cursor: pointer;
}
input[type=contact] {
    width: 100%;
    background-color: Grey;
    color: white;
    padding: 5px 1px;
    margin: 7px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}


</style>


<div class="info">
  <form method="POST">
    <label for="yname">Name</label>
    <input type="tt" id="yname" name="Yourname" placeholder="Your name.."><br>

    <label for="email">Email</label>
    <input type="tt" id="email" name="email" onblur="validateEmail(this);"  placeholder="Your email"><br>

      <label for="phonen">Phone Number</label>
    <input type="tt" id="phonen" name="phone"  maxlength="10" placeholder="Your phone no" onkeypress="return isNumberKey(event)"/><br>

     <label for="msg">Message</label>
    <input type="tt" id="phonen" name="msg" title="Mention the message in this column" maxlength="200" placeholder="Your message 150-200 words.."><br>
  
    <input type="contact" value="HOW YOU WOULD LIKE TO BE CONTACTED?" title="Please select Phone or Email"><br>
    

  <input type="radio" name="Phone" value="Phone" checked>Phone<input type="radio" name="Email" value="Email">Email<br>
 
<input type="submit" value="Send Message" name="ok">
  
  </form>
</div


</body>
</html>

<?php

require 'config.php';


if(isset($_POST["ok"]))
{

$name=$_POST["Yourname"];

$email=$_POST["email"];
$tel=$_POST["phone"];

$sql="INSERT INTO contact VALUES ('$name','$email',$tel)";

if(mysqli_query($con,$sql)){
echo "success";}
else{
  echo "failed";}
}

mysqli_close($con);
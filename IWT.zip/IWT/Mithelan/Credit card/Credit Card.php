<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
{
$user_name=$_SESSION['SESS_USERNAME'];
}

require 'config.php';

?>

<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<script src="formvalid.js"></script>

</head>
<style>
body{
    background-image:url(images/m.jpg)

}
</style>
<header>
<body>
<img src="images/logo.jpg" alt="logo Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/User.jpg" alt="user" class="user_image">

<div class="link">
<a href="#">Log in</a>
</div>

<div class="link_cart">
<pre>
   <a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
<b><li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li></b>
</ul>
<hr id="hr">




<h2><center>Credit or Debit Card</h2></center>

<form method="POST">
  <div class="container">
<center>
<label for="firstname"><b>First Name</b></label>
    <input type="txt" placeholder="First name" name="fn" required><br>


<label for="lastname"><b>Last Name</b></label>
    <input type="txt" placeholder="Last Name" name="ln" required><br>
<label for="card no"><b>Card Number</b></label>
    <input type="txxt" maxlength="20" placeholder="Card Number" name="CN" onkeypress="return isNumberKey(event)"/><br></center>
<div class="cvv">
<pre><label for="CVV"><b>CVV(Security Code)</b></label>
    <input type="cvv" placeholder="3 digits number" maxlength="" name="cvv" title="Last 3 digits in back of your debit/credit card" onkeypress="return isNumberKey(event)"/>   Expiry date: <input type="date" name="exp" min="2018-01-01" max="2030-12-31"></pre>
</div>
 

  <center>  <button type="add" class="addthecard" name="ok" >Add the card </button></center>
<a href="../Paypal/Paypal.php"><button type="next" class="addthecard" name="nextpaypal">Change to Paypal Payment</button></a>
</div>
</form>







<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>


</body>
</html>

<?php




if(isset($_POST['ok']))
{

$fname=$_POST['fn'];
$lname=$_POST['ln'];
$cname=$_POST['CN'];
$cvv=$_POST['cvv'];
$ex_date=$_POST['exp'];

$sql="INSERT INTO card VALUES ('$user_name','$fname','$lname',$cname,$cvv,'$ex_date')";

if(mysqli_query($con,$sql))
{
   
   header('location: ../../Suthakar/login.php');

}
else
{
  header('location: Credit Card.php');

}
}

?>
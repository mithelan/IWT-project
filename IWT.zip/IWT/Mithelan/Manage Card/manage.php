<?php
session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
$user_name=$_SESSION['SESS_USERNAME'];

?>

<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<script src="formvalid.js"></script>

</head>
<style>
body{
    background-image:url(images/m2.jpg)
 

}

table {
    border-collapse: collapse;
    width: 90%;
}

th, td {
    text-align: left;
    padding: 9px;
}

tr:nth-child(even) {background-color: #f2f2f2;}

input[type=submit] {
    width:20%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 1px 1px;
    border: none;
    border-radius: 2px;
    cursor: pointer;
}
input[type=text] {
    width:20%;
  background-color:white;
     color: black;
    padding:8px 15px;
    margin: 1px 1px;
    border: none;
    border-radius: 2px;
    cursor: pointer;
}
</style>
<header>
<body>
<img src="images/logo.jpg" alt="logo Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/User.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}



?> 
</div>

<div class="link_cart">
<pre>
  <a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
<b><li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li></b>
</ul>
<hr id="hr">


<h2><center>Manage your Cards</center></h2>

<?php

require 'config.php';

$sql="SELECT * FROM card where username='$user_name'";

$result=mysqli_query($con,$sql);

?>

<table border="2">
   <tr>
      <th>Card Number</th>
      <th>Card Holder</th>
	  <th>Expiry Date</th>
    </tr>
    <?php 
    if ($result->num_rows > 0) 
	{
    while($row = $result->fetch_assoc())
    {
      
        print "<tr> <td>";
        echo $row["cname"];
        $_SESSION["cname"]=	$row["cname"];	
        print "</td>";

        print "<td>";
        echo $row["fname"].' '.$row["lname"]; 
        print "</td>";
		
		print "<td>";
        echo $row["ex_date"]; 
        print "</td></tr>";
    }
  }

  else
  {
        print "<tr> <td>";
        echo "No cards to display"; 
        print "</td> </tr>";
		
  }

    ?>
</table>
<form method="POST">
<center>
<input type="text" name="del" placeholder="Enter"><br>
<input type="submit" name="delete" value="Delete"><br>
<input type="submit" name="update" value="Update"><br>
</form></center>


<?php

if(isset($_POST['delete']))
{
	
$card_no=$_POST['del'];

$sql="DELETE FROM card where cname='$card_no'";

if(mysqli_query($con,$sql))
{
	header ('location:manage.php');
}

}

if(isset($_POST['update']))
{

$card_no=$_SESSION["cname"];	
	
$text=$_POST['del'];

$sql="UPDATE card SET ex_date='$text' where cname='$card_no'";

if(mysqli_query($con,$sql))
{
	header ('location:manage.php');
}
else{
	echo "failed";
}
}

?>


<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>


</body>
</html>
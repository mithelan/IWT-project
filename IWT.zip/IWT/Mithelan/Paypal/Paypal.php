<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
$user_name=$_SESSION['SESS_USERNAME'];

?>
<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="stylesheet.css">
<script src="formvalid.js"></script>



</head>

<style>
body{
    background-image:url(images/check4.jpg)
 
}
</style>
<body>
<header>
<img src="logo.jpg" alt="logo Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="User.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}



?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>s
</div>

<h2 class="h2">Live Art</h2>
<hr id="hr">
<ul class="nav">
<b>
<b><li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li></b>
</ul>
<hr id="hr">
</header>




<div align="left">

<u><p><font color="gold">Back to the previous page</font></p></u>
</div>

<img src="images/paypall.png" alt="paypal Image" id="payimage">

<form method="POST">
  <div class="container">
 <form name="myForm"onsubmit="return validateForm();" method="post">
 <div class="mail">
 

    <input type="txt" onblur="validateEmail(this);" placeholder="Email" name="EM" required>

    <input type="password" placeholder="Password" name="pwd" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

<center><u><font color="black"><a  href="#forgot ">Forgot your password</a></font></center>

    <button type="add" value="submit" name="ok" class="login">Log In</button></div>
</form>
</div>


  <font color="black"><p id="createaccount"><a  href="#create ">Create an Account</a></font>


  <div align="right">
<button type="change" class="edit">Change to debit/credit payment</button>
     </div>
</form>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

</body>
</html>

<?php

require 'config.php';

?>

<?php

if(isset($_POST["ok"])){

$uname=$_POST["EM"];

$pass=$_POST["pwd"];


$sql="INSERT INTO paypal VALUES ('$uname','$pass')";

if(mysqli_query($con,$sql)){
echo "success";}
else{
  echo "failed";}
}

mysqli_close($con);
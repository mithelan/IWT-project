<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else

   if ($_SESSION['SESS_IS_ADMIN']==1) 
   {
     $user_name=$_SESSION['SESS_USERNAME'];
   }
   else
   {
    header('location:../Suthakar/login.php');
   }

?>

<html>
<head>
<title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body{
    background-image:url(images/index8.jpg);
}

#image{
float:left;
margin-left:10px;
margin-top:10px;
width:100px;
height:50px;
}
.search{
    float: left;
    padding: 5px;
    margin-top: 25px;
    margin-left:20px;
    font-size: 17px;
    width:300px;
}
.h2{
   align:left;
    margin-top: 45px;
    margin-left:17px;

   
}
.user_image{
     margin-right:5px;
     float:right;
     width:100px;
     height:50px;
}
.link{
    float:right;
    margin-right:20px;
    
    padding:5px;
}
.link_cart{
    float:right;
    margin-right:40px;
    margin-top:10px;
   
}
.link_cart a{
     text-decoration:none;
}
.nav {
  
  border-width:1px 0;
  list-style:none;
  margin:0px;
  padding:0;
  text-align:center; 
 
}

.nav li {
  display:inline;
}

.nav a {
  display:inline-block;
  padding:3px;
  text-decoration:none;
  color:black;
}
.nav a:hover{
     text-decoration:underline;
}
#hr{
  height:3px;
  background-color: black;
  border:none;
}
.footer{
   position:relative;
   bottom:-22px;
   border-top-style:solid;
   width:100%;
}
.align_footer{
      float:left;
      margin-left: -150px;
}
.address{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    padding:10px;
}
.tel{
    border: 1px solid black;
    width:270px;
    margin-top:10px;
    margin-left:150px;
    margin-bottom:5px;
    padding:5px;
}
.fa {
  padding: 10px;
  font-size: 10px;
  width: 10px;
  text-decoration:none;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-youtube {
  background: #bb0000;
  color: white;
}
.social_medias{
   float:right;
   margin-top:30px;
   margin-right:-120px;
}
.follow{
   margin-right:40px;
   margin-top:5px;
}
.sidebar{
   float:left;
}
.vertical{
    border-left:3px solid black;
    position:absolute;
    height:705px;
    float:left;
    margin-left:200px;
    margin-top:-547px;
}
html *{
    font-family:sans-serif;
}
.signout{
    background-color: #4CAF50;
    border:none;
    color: white;
    padding: 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 10px 49px;
    border-radius: 5px;
    width:110;
}
.signout:hover{
    cursor:pointer;
    }

.button{
    background-color: white;
    border: none;
    color: black;
    padding: 8px 5px;
    text-align: left;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    width:125;
    height:30;
}
.button:hover {
    background-color: #e6e6e6;
    
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
th {
    text-align: left;
}
.icon{
    border:1px solid black;
    width:250;
    height:200;
}
.icon:hover{
    cursor:pointer;
    background-color: #e6e6e6;
}
.social a{
    display:table;
    padding:8px;
    margin:-5 0 0 40;
}
ul.list{
    list-style-type: none;
    
}
</style>
</head>
<body>

<header>
<img src="images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 
if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
  <li><a href="../MR/Homepage.php">Home</a></li>
  <li><a href="../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">

<div>
<img src="images/admin.jpg" width=110 height=100 style="margin-left:45px;margin-top:20px;margin-bottom:20px;"><br>
<label style="margin-left:70px;top:200px;"><b><?php echo $user_name; ?></b></label><br>
<a href="../Suthakar/logout.php"><button class="signout" style="margin:15 0 70 45;">Sign Out</button></a><br>
<img src="images/compass.png" width=20 height=20 style="margin:0px 20 	5 0;"><button class="button"><b style="position:relative;bottom:3;">Dashboard</b></button><br>
<img src="images/files.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Uploads</label></button><br>
<img src="images/comment.jpg" width=20 height=20 style="margin:15px 20 0 0;"><a href="Adminpage3.php"><button class="button"><label style="position:relative;bottom:3;">Feedback</label></button></a><br>
<img src="images/report.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Report</label></button><br>
<img src="images/help.jpg" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Help Requests</label></button><br>
<img src="images/i.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Notifications</label></button><br>
</div>
<div class="vertical"></div>
<div><img src="images/line.png" width=700 height=200 style="position:relative; margin: -500 0 0 250;">
</div>
<label style="position:absolute;margin:-470 0 0 950;"><b>Views</b></label>
<img src="images/pie.png" width=200 height=180 style="float:right;margin:-500 40 0 0">
<label style="float:right;margin:-300 100 0 0"><b>Surf Time</b></label>
<div style="margin:-150 0 0 253">


<?php
  
require 'config.php';

$sql="SELECT fname, lname from user LIMIT 4";	
$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)>0)
{
  echo "<table><tr><th>First Name</th><th>Lastname</th></tr>";
	
  while($row = $result->fetch_assoc())
  {
    echo "<tr><td>". $row["fname"]."</td><td>". $row["lname"]."</ td></td>";
  } echo "</table>";
}
?>
</div>
<div>
<img src="images/bar.jpg" width=150 height=130 style="float:right;margin:-140 40 0 0">
<label style="float:right;margin:-140 200 0 0;"><b>Sales</b></label>
<label style="float:right;margin:-10 50 0 0;"><b>Artist</b></label>
</div>
<div><div  class="icon" style="margin:30 0 0 230">
<img src="images/add.jpg" width=90 height=90 style="margin:40 0 0 80;"><br>
<label style="position:absolute;margin:30 0 0 60"><b>Add Submissions</b></label>
</div>
</div>
<div><div  class="icon" style="margin:-202 0 0 500">
<img src="images/edit.png" width=90 height=90 style="margin:40 0 0 80;"><br>
<label style="position:absolute;margin:30 0 0 90"><b>Edit Site</b></label>
</div>
</div>
<div><div  class="icon" style="margin:-202 0 0 770">
<img src="images/generate.png" width=90 height=90 style="margin:40 0 0 80;"><br>
<label style="position:absolute;margin:30 0 0 40"><b>Generate Sales Report</b></label>
</div>
</div>
<div>
<div  class="icon" style="margin:-202 0 0 1040">
<div class="social">
<ul class="list">
<li><a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a><li><br>
<li><a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a></li><br>
<li><a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a></li><br>
<li><a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a></li><br>
<li><a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a></li>
</ul>
<label style="position:absolute;margin:-195 0 0 120;font-size:20px;"><b>12K</b></label>
<label style="position:absolute;margin:-157 0 0 120;font-size:20px;"><b>52K</b></label>
<label style="position:absolute;margin:-117 0 0 120;font-size:20px;"><b>27K</b></label>
<label style="position:absolute;margin:-78 0 0 120;font-size:20px;"><b>95K</b></label>
<label style="position:absolute;margin:-39 0 0 120;font-size:20px;"><b>557K</b></label>
</div>
</div>
</div>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

</body>
</html>
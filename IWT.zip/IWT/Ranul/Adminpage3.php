<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else

   if ($_SESSION['SESS_IS_ADMIN']==1) 
   {
     $user_name=$_SESSION['SESS_USERNAME'];
   }
   else
   {
    header('location:../Suthakar/login.php');
   }



?>

<html>
<head>
<title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body{
    background-image:url(images/index8.jpg);
}

#image{
float:left;
margin-left:10px;
margin-top:10px;
width:100px;
height:50px;
}
.search{
    float: left;
    padding: 5px;
    margin-top: 25px;
    margin-left:20px;
    font-size: 17px;
    width:300px;
}
.h2{
   align:left;
    margin-top: 45px;
    margin-left:17px;

   
}
.user_image{
     margin-right:5px;
     float:right;
     width:100px;
     height:50px;
}
.link{
    float:right;
    margin-right:20px;
    
    padding:5px;
}
.link_cart{
    float:right;
    margin-right:40px;
    margin-top:10px;
   
}
.link_cart a{
     text-decoration:none;
}
.nav {
  
  border-width:1px 0;
  list-style:none;
  margin:0px;
  padding:0;
  text-align:center; 
 
}

.nav li {
  display:inline;
}

.nav a {
  display:inline-block;
  padding:3px;
  text-decoration:none;
  color:black;
}
.nav a:hover{
     text-decoration:underline;
}
#hr{
  height:3px;
  background-color: black;
  border:none;
}
.footer{
   position:relative;
   bottom:-150px;
   border-top-style:solid;
   width:100%;
}
.align_footer{
      float:left;
      margin-left: -150px;
}
.address{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    padding:10px;
}
.tel{
    border: 1px solid black;
    width:270px;
    margin-top:10px;
    margin-left:160px;
    margin-bottom:5px;
    padding:5px;
}
.fa {
  padding: 10px;
  font-size: 10px;
  width: 10px;
  text-decoration:none;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-youtube {
  background: #bb0000;
  color: white;
}
.social_medias{
   float:right;
   margin-top:30px;
   margin-right:-120px;
}
.follow{
   margin-right:40px;
   margin-top:5px;
}
.sidebar{
   float:left;
}
.vertical{
    border-left:3px solid black;
    position:absolute;
    height:697px;
    float:left;
    margin-left:200px;
    margin-top:-547px;
}
html *{
    font-family:sans-serif;
}
.signout{
    background-color: #4CAF50;
    border:none;
    color: white;
    padding: 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 10px 49px;
    border-radius: 5px;
    width:110;
}
.signout:hover{
    cursor:pointer;
    }

.button{
    background-color: white;
    border: none;
    color: black;
    padding: 8px 5px;
    text-align: left;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    width:125;
    height:30;
}
.button:hover {
    background-color: #e6e6e6;
    
}

.h1{
  float: left;
  margin-left: 250px;
  margin-top: -510px;
}
.table{
    margin-top: -400px;
    margin-left: 250px;
    width: 50%;
}

</style>
</head>
<body>

<header>
<img src="images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 
if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
?>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
  <li><a href="../MR/Homepage.php">Home</a></li>
  <li><a href="../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">

<div>
<img src="images/admin.jpg" width=110 height=100 style="margin-left:45px;margin-top:20px;margin-bottom:20px;"><br>
<label style="margin-left:70px;top:200px;"><b><?php echo $user_name; ?></b></label><br>
<a href="../Suthakar/logout.php"><button class="signout" style="margin:15 0 70 45;">Sign Out</button></a><br>
<img src="images/compass.png" width=20 height=20 style="margin:0px 20 	5 0;"><a href="Adminpage.php"><button class="button"><b style="position:relative;bottom:3;">Dashboard</b></button></a><br>
<img src="images/files.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Uploads</label></button><br>
<img src="images/comment.jpg" width=20 height=20 style="margin:15px 20 0 0;"><a href="Adminpage3.php"><button class="button"><label style="position:relative;bottom:3;">Feedback</label></button></a><br>
<img src="images/report.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Report</label></button><br>
<img src="images/help.jpg" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Help Requests</label></button><br>
<img src="images/i.png" width=20 height=20 style="margin:15px 20 0 0;"><button class="button"><label style="position:relative;bottom:3;">Notifications</label></button><br>
</div>
<div class="vertical"></div>

<div class="h1">
<h2>Feedbacks</h2>
</div>

<?php

require 'config.php';

$sql="SELECT * FROM feedback where username='$user_name'";

$result=mysqli_query($con,$sql);

?>

<table border="2" class="table">
   <tr>
      <th>Username</th>
      <th>Rate</th>
      <th>Improvement</th>
   </tr>

<?php 

    if ($result->num_rows > 0) 
    {
    while($row = $result->fetch_assoc())
    {
      
        print "<tr> <td>";
        echo $row["username"];  
        print "</td>";

        print "<td>";
        echo $row["rate"]; 
        print "</td>";
    
        print "<td>";
        echo $row["improvement"]; 
        print "</td></tr>";
    }
  }

  else
  {
        print "<tr> <td colspan=3>";
        echo "<center>No feedbacks to display</center>"; 
        print "</td> </tr>";
    
  }

?>
<form method="POST">
<div style="float: right; margin-right: 650px;">
<input type="text" name="text" placeholder="Enter Improvement to delete">
</div>

<div style="clear:right;float: right; margin-right: 590px;margin-top: -22px;">
<input type="submit" name="delete" value="Delete">
</div>
</form>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtube.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>

</body>
</html>

<?php

require 'config.php';

if (isset($_POST['delete'])) 
{
  $text=$_POST['text'];

  $sql="DELETE FROM feedback WHERE improvement='$text'";

  mysqli_query($con,$sql);
  
}

?>
<?php

session_start();

 if (empty($_SESSION['SESS_USERNAME'])) 
 {
   header('location:../Suthakar/login.php');
 }
 else
 {
    $user_name=$_SESSION['SESS_USERNAME'];
 }
?>

<html>
<head>
<title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body{
    background-image:url(images/index8.jpg);
}

#image{
float:left;
margin-left:10px;
margin-top:10px;
width:100px;
height:50px;
}
.search{
    float: left;
    padding: 5px;
    margin-top: 25px;
    margin-left:20px;
    font-size: 17px;
    width:300px;
}
.h2{
   align:left;
    margin-top: 45px;
    margin-left:17px;

   
}
.user_image{
     margin-right:5px;
     float:right;
     width:100px;
     height:50px;
}
.link{
    float:right;
    margin-right:20px;
    
    padding:5px;
}
.link_cart{
    float:right;
    margin-right:40px;
    margin-top:10px;
   
}
.link_cart a{
     text-decoration:none;
}
.nav {
  
  border-width:1px 0;
  list-style:none;
  margin:0px;
  padding:0;
  text-align:center; 
 
}

.nav li {
  display:inline;
}

.nav a {
  display:inline-block;
  padding:3px;
  text-decoration:none;
  color:black;
}
.nav a:hover{
     text-decoration:underline;
}
#hr{
  height:3px;
  background-color: black;
  border:none;
}
.footer{
   position:relative;
   bottom:-510px;
   border-top-style:solid;
   width:100%;
}
.align_footer{
      float:left;
      margin-left: -150px;
}
.address{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    padding:10px;
}
.tel{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:150px;
    margin-bottom:5px;
    padding:5px;
}
.fa {
  padding: 10px;
  font-size: 10px;
  width: 10px;
  text-decoration:none;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-youtube {
  background: #bb0000;
  color: white;
}
.social_medias{
   float:right;
   margin-top:30px;
   margin-right:-120px;
}
.follow{
   margin-right:40px;
   margin-top:5px;
}
.radio{
   color:#cccc00;
}
</style>
<script>
function validate() {
    if(document.getElementById("text_area").value=="")
    {   alert("Text field is empty");
    }
}
</script>
</head>
<body>
<header>
<img src="images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/user.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../MR/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../Vyhari/user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}



?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
  <li><a href="../MR/Homepage.php">Home</a></li>
  <li><a href="../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">
<div style="position:relative;margin:50 0 -500 450;">
<p style="font-family:sans-serif;"><b>Leave us your valuable feedback,</b></p>
<p style="font-family:sans-serif;"><b>How did you feel about the serviceyou received today?</b></p>

<form method="POST">
<input type="radio" name="radio" value="Very satisfied"> <label class="radio">Very satisfied</label><br>
<input type="radio" name="radio" value="Satisfied"> <label class="radio">Satisfied</label><br>
<input type="radio" name="radio" value="Average"> <label class="radio">Average</label><br>
<input type="radio" name="radio" value="Unsatisfied"> <label class="radio">Unsatisfied</label><br>
<input type="radio" name="radio" value="Very unsatisfied"> <label class="radio">Very unsatisfied</label><br>
<p style="font-family:sans-serif;"><b>How could we improve this service?</b></p>
<textarea id="text_area" rows="6" cols="57" name="improve"></textarea>
<br>
<button onclick="validate()" style="margin-bottom:40px;padding:15px;background-color:#ffffcc;" name="send">Send Feedback</button>
</div>
</form>

<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>
</body>
</html>

<?php

require 'config.php';

if(isset($_POST['send']))
{
   $rate=   $_POST['radio'];
   $improve=$_POST['improve'];

   $sql="INSERT INTO feedback  VALUES ('$user_name','$rate','$improve')";

   if (mysqli_query($con,$sql)) 
   {
   	echo "success";
   }
   else
   {
   	echo "failed";
   }

}





?>
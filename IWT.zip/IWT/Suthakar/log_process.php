<?php
	
	session_start();

	require 'config.php';

	//Input Validations
	if(empty($_POST['username'])) 
	{
		$_SESSION["username_error"]  = 'Please provide a username.';
		header("location: login.php");
	}
	else if(empty($_POST['password'])) 
	{
		$_SESSION["password_error"] = 'Please enter the password.';
		header("location: login.php");
	}

	if (isset($_POST['sub'])) {
	
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql="SELECT * FROM user WHERE username='$username' AND password='".md5($_POST['password'])."'";
	$result=mysqli_query($con,$sql);

    //Checking query (success)
	if($result) 
	{
		if(mysqli_num_rows($result) == 1) 
		{
			//Login Successful
			$member = mysqli_fetch_assoc($result);
			$_SESSION['SESS_USERNAME'] = $member['username'];
			$_SESSION['SESS_IS_ADMIN'] = $member['is_admin'];
			$_SESSION['SESS_IS_ARTIST'] = $member['is_artist'];
			header("location: ../MR/Homepage.php");
		}
		else 
		{
			//Login failed
			$_SESSION['login_fail'] = 'Incorrect username or password. Please try again.';
			header("location: login.php");
		}
	}
    else 
	{
		die("Query failed: ".mysqli_error($con));
	}
}

?>
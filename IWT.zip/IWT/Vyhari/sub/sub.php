<?php

session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
$user_name=$_SESSION['SESS_USERNAME'];

?>

<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

#image{
float:left;
margin-left:10px;
margin-top:10px;
width:100px;
height:50px;
}
.search{
    float: left;
    padding: 5px;
    margin-top: 25px;
    margin-left:20px;
    font-size: 17px;
    width:300px;
}
.h2{
   align:left;
    margin-top: 45px;
    margin-left:17px;

   
}
.user_image{
     margin-right:5px;
     float:right;
     width:100px;
     height:50px;
}
.user_icon{
     margin-right:5px;
     float:right;
     width:150px;
     height:120px;
}
.link{
    float:right;
    margin-right:20px;
    
    padding:5px;
}
.link_cart{
    float:right;
    margin-right:40px;
    margin-top:10px;
   
}
.link_cart a{
     text-decoration:none;
}
.nav {
  
  border-width:1px 0;
  list-style:none;
  margin:0px;
  padding:0;
  text-align:center; 
 
}

.nav li {
  display:inline;
}

.nav a {
  display:inline-block;
  padding:3px;
  text-decoration:none;
  color:black;
}
.nav a:hover{
     text-decoration:underline;
}
#hr{
  height:3px;
  background-color: black;
  border:none;
}
.footer{
   position:relative;
   bottom:-510px;
   border-top-style:solid;
   width:100%;
}
.align_footer{
      float:left;
      margin-left: -1075px;
}
.address{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    padding:10px;
}
.tel{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    margin-bottom:5px;
    padding:5px;
}
.fa {
  padding: 10px;
  font-size: 10px;
  width: 10px;
  text-decoration:none;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-youtube {
  background: #bb0000;
  color: white;
}
.social_medias{
   float:right;
   margin-top:30px;
   margin-right:-120px;
}
.follow{
   margin-right:40px;
   margin-top:5px;
}
.ul{
   list-style-type:square;
   margin-left:-16px;
   margin-top:-10px;
}
.ul a{
     text-decoration:none;
}
.ul a:hover{
     text-decoration:underline;
}
.selectbox{
    width: 150px;
    height: 30px;
}
.sidebar{
     float:left;
}
.vertical{
    border-left:3px solid black;
    height:500px;
    float:left;
    margin-left:10px;
}
#user{
    margin-left:35px;
   }
.signout{
    margin-left:35px;
   }
#mithe{
    margin-left:20px;
}

</style>
</head>
<body background="images/index8.jpg">
<header >
<img src="images/logo.jpg" alt="Insert Image" id="image">
<input type="text" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/User.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../MR/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}

?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>

<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
  <li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">





<div class="sidebar">
<img src="images/download.png" alt="user icon" class="user_icon" >
<p id="user"><b>@###user</b></p>

<form action="/action_page.php">
  <div class="container">

<div class="signout">

<b><button type="signout" class="login">Sign Out</button></b>
</div></form>
<p id="mithe"><u><font color="Green">Profile</font></u></p>
</div>


<i class="fa fa-user-circle-o" style="font-size:20px;float:left;"></i>
<p style="float:left;margin-top:12px;margin-left:8px;"><b>My Profile</b></p>
<br><br>
<i class="fa fa-gear" style="font-size:20px;float:left;margin-left:-111px;"></i>
<p style="float:left;margin-left:8px;margin-top:-30px; margin-left:36px;">Account Settings</p>
<br><br>
<i class="fa fa-shopping-cart" style="font-size:20px;margin-top:-9px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;">My Order</p>
<br><br>
<i class="fa fa-group" style="font-size:20px;margin-top:-1px;float:left;margin-left:-98px"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;">My Subscriptions</p>
<br><br>
<i class="fa fa-credit-card" style="font-size:20px;margin-top:-9px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;"><a href="#">Card Manager</a></p>
<br><br>
<i class="fa fa-lock" style="font-size:24px;margin-top:-4px;margin-left:-118px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top:-1px;margin-left:4px;">Security</p>
</div>

<div class="vertical">

<h1 style="text-align:center;margin-left:80px">My Subscription</style></h1>
<br>
<img style="margin-left: 145px;margin-top:-25px;"src="images/index.jpg" alt="Trulli" width="200" height="150">
<img style="margin-left: 350px;margin-top:-25px;"src="images/index1.jpg" alt="Trulli" width="200" height="150">
<br>
<p style="float:left;margin-left:180px;margin-top:-6px;"><u><font color="Blue">MARC MUGINER</font></u></p>
<p style="float:left;margin-left:420px;margin-top:-6px;"><u><font color="Green">ASHVIN HARRISON</font></u></p>
<br><br><br>
<img style="margin-left: 145px;"src="images/index3.jpg" alt="Trulli" width="200" height="150">
<img style="margin-left: 350px;"src="images/index4.jpg" alt="Trulli" width="200" height="150">
<br>
<p style="float:left;margin-left:180px;margin-top:-6px;"><u><font color="Red">ESCOBAR HENRY</font></u></p>
<p style="float:left;margin-left:440px;margin-top:-6px;"><u><font color="Orange">JEAN MIRRE</font></u></p>
</div>


<div footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>
</body>
</html>
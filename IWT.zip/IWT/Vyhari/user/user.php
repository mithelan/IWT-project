<?php
session_start();

if (empty($_SESSION['SESS_USERNAME'])) 
{
  header('location:../Suthakar/login.php');
}
else
$user_name=$_SESSION['SESS_USERNAME'];
?>

<html>
<head>
      <title>Live Art</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

#image{
float:left;
margin-left:10px;
margin-top:10px;
width:100px;
height:50px;
}
.search{
    float: left;
    padding: 5px;
    margin-top: 10px;
    margin-left:50px;
    font-size: 17px;
    width:300px;
}
.h2{
   align:left;
    margin-top: 45px;
    margin-left:-100px;

   
}
.user_image{
     margin-right:5px;
     float:right;
     width:100px;
     height:50px;
}
.user_icon{
     margin-right:5px;
     float:right;
     width:150px;
     height:120px;
}
.link{
    float:right;
    margin-right:20px;
    
    padding:5px;
}
.link_cart{
    float:right;
    margin-right:40px;
    margin-top:10px;
   
}
.link_cart a{
     text-decoration:none;
}
.nav {
  
  border-width:1px 0;
  list-style:none;
  margin:0px;
  padding:0;
  text-align:center; 
 
}

.nav li {
  display:inline;
}

.nav a {
  display:inline-block;
  padding:3px;
  text-decoration:none;
  color:black;
}
.nav a:hover{
     text-decoration:underline;
}
#hr{
  height:3px;
  background-color: black;
  border:none;
}
.footer{
   position:relative;
   bottom:-510px;
   border-top-style:solid;
   width:100%;
}
.align_footer{
      float:left;
      margin-left: -800px
}
.address{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    padding:10px;
}
.tel{
    border: 1px solid black;
    width:240px;
    margin-top:10px;
    margin-left:20px;
    margin-bottom:5px;
    padding:5px;
}
.fa {
  padding: 10px;
  font-size: 10px;
  width: 10px;
  text-decoration:none;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-youtube {
  background: #bb0000;
  color: white;
}
.social_medias{
   float:right;
   margin-top:30px;
   margin-right:-120px;
}
.follow{
   margin-right:40px;
   margin-top:5px;
}
.ul{
   list-style-type:square;
   margin-left:-16px;
   margin-top:-10px;
}
.ul a{
     text-decoration:none;
}
.ul a:hover{
     text-decoration:underline;
}
.selectbox{
    width: 150px;
    height: 30px;
}
.sidebar{
     float:left;
}
.vertical{
    border-left:3px solid black;
    height:500px;
    float:left;
    margin-left:10px;
}
#user{
    margin-left:35px;
   }
#user1{
    margin-left:35px;
    margin-bottom: -35px;
   }
.signout{
    margin-left:35px;
   }
#mithe{
    margin-left:20px;
}
input[type=submit] {     
width: 37%;     
color: black;     
padding: 14px 20px;     
margin: 16px 130px;     
border: none;     
border-radius: 4px;     
cursor: pointer; 
} 
input[type=text], select {     
width:33%;     
padding: 5px 20px;     
margin: -9px 18px;     
display: inline-block;     
border: 1px solid #ccc;     
border-radius: 4px;     
box-sizing: border-box; 
}
input[type=text1], select {     
width:28%;     
padding: 5px 20px;     
margin: 16px 18px;     
display: inline-block;     
border: 1px solid #ccc;     
border-radius: 4px;     
box-sizing: border-box;

</style>
</head>
<body background="images/index8.jpg">
<header >
<img src="images/logo.jpg" alt="Insert Image" id="image">
<input type="text1" placeholder="Search,artists,galleries.." class="search"><br>
<img src="images/User.jpg" alt="user" class="user_image">

<div class="link">
<?php 

if(empty($_SESSION['SESS_USERNAME']))
{

echo '<a href="'.'../../Suthakar/login.php"'.'>Log in</a>';       


}
else if ($_SESSION['SESS_IS_ADMIN']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../Ranul/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}
else if ($_SESSION['SESS_IS_ARTIST']==1) 
{
echo '<span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
echo '<br>'.'<a href="'.'../../MR/Adminpage.php"'.'>Administration</a>';
echo '<br>'.'<a href="'.'../Suthakar/logout.php"'.'>Log out</a>';
}
else
{
  echo '<br><span style="'.'color:gold;"'.'>'.'<a href="'.'../user/user.php">'.$_SESSION['SESS_USERNAME'].'</a></span>';
  echo '<br>'.'<a href="'.'../../Suthakar/logout.php"'.'>Log out</a>';
}

?>
</div>

<div class="link_cart">
<pre>
<a href="#">Shopping Cart</a>
</pre>
</div>
<h2 class="h2">Live Art</h2>
</header>
<hr id="hr" style="margin-top:-20px;">
<ul class="nav">
  <li><a href="../../MR/Homepage.php">Home</a></li>
  <li><a href="../../MR/Artists.php">Artists</a></li>
  <li><a href="#formatsandprices">Formats and Prices</a></li>
  <li><a href="#auctions">Auctions</a></li>
  <li><a href="#shipping">Shipping</a></li>
  <li><a href="../../Mithelan/contact us page/Contact us.php">Contact Us</a></li>
  <li><a href="../../Ranul/Feedback.php">Feedback</a></li>
</ul>
<hr id="hr">

<div class="sidebar">
<img src="images/download.png" alt="user icon" class="user_icon" >
<p id="user"><b><?php echo $user_name; ?></b></p>

<form method="POST">
  <div class="container">

<div class="signout">

<b><button type="submit" class="login"><a href="../../Suthakar/logout.php">Sign Out</a></button></b>
</div></form>
<p id="mithe"><u><font color="Green">Profile</font></u></p>
</div>


<i class="fa fa-user-circle-o" style="font-size:20px;float:left;"></i>
<p style="float:left;margin-top:12px;margin-left:8px;"><b><a href="user.php">My Profile</a></b></p>
<br><br>
<i class="fa fa-gear" style="font-size:20px;float:left;margin-left:-111px;"></i>
<p style="float:left;margin-left:8px;margin-top:-30px; margin-left:36px;"><a href="../account/account.php">Account Settings</a></p>
<br><br>
<i class="fa fa-shopping-cart" style="font-size:20px;margin-top:-9px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;"><a href="#">My Order</a></p>
<br><br>
<i class="fa fa-group" style="font-size:20px;margin-top:-1px;float:left;margin-left:-98px"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;"><a href="#">My Feedbacks</a></p>
<br><br>
<i class="fa fa-credit-card" style="font-size:20px;margin-top:-9px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top: 3px;margin-left: 6px;"><a href="../../Mithelan/Manage Card/manage.php">Card Manager</a></p>
<br><br>
<i class="fa fa-lock" style="font-size:24px;margin-top:-4px;margin-left:-118px;float:left;"></i>
<p style="float:left;margin-left:8px;margin-top:-1px;margin-left:4px;"><a href="#">Security</a></p>
</div>

<div class="vertical">

<h1 style="text-align:center;">My Profile</style></h1>
<br>

<?php

require 'config.php';

// if (!empty($_SESSION['SESS_USERNAME'])) 
// {
//   $member['username']=$_SESSION['SESS_USERNAME'];
// }


$sql ="SELECT * FROM user WHERE username='$user_name'";

$result = mysqli_query($con,$sql);

if($result) 
  {
    if(mysqli_num_rows($result) == 1) 
    {
      $member = mysqli_fetch_assoc($result);

      $_SESSION['SESS_NAME'] = $member['fname'].' '.$member['lname'];
      $_SESSION['SESS_USER_NAME'] = $member['username'];
      $_SESSION['SESS_IS_EMAIL'] = $member['email'];
      $_SESSION['SESS_IS_USER_AGE'] = $member['Age'];
      $_SESSION['SESS_IS_USER_DOB'] = $member['DOB'];
      $_SESSION['SESS_IS_USER_GENDER'] = $member['Gender'];
      $_SESSION['SESS_IS_USER_STYLE'] = $member['Art_styles'];
      $_SESSION['SESS_IS_USER_MOBILE'] = $member['Mobile'];
      $_SESSION['SESS_IS_USER_DESC'] = $member['Description'];
    }
  }
  ?>
  
 <form method="POST">
  <p id="user1">Name: <input type="text" name="name" value="<?php echo $member['fname'].' '.$member['lname'];?>"> </p><br><br>
  <p id="user1">Age: <input type="text" name="age" value="<?php echo $member['Age'];?>"> </p><br><br>
  <p id="user1">DOB: <input type="text" name="dob" value="<?php echo $member['DOB'];?>"> </p><br><br>
  <p id="user1">Gender:<input type="text" name="gender" value="<?php echo $member['Gender']; ?> "> </p><br><br>
  <p id="user1">Interested Art styles: <input type="text" name="Art" value="<?php echo $member['Art_styles'];?> "></p><br><br>
  
  <p id="user1">Mobile No: <input type="text" name="tel" value="<?php echo $member['Mobile'];?>"> </p><br><br>
  <p id="user1"><textarea rows="8" cols="80" placeholder="Description" name="text"><?php echo $member['Description'];?> </textarea></p>

 <center>  <button type="submit" class="save" name="save">save</button></center>
</div>


<footer class="footer">
<div class="align_footer">
<div class="tel">
<b>Address: 77, Lorenz Road, Col-04</b>
</div>
<div class="tel">
<b>TEL:0112888888 FAX:0112887777</b>
</div>
</div>
<p class="follow" style="float:right;"><b>Follow Us On</b></p>
<div class="social_medias">
<a href="https://www.facebook.com/LiveArt" class="fa fa-facebook"></a>
<a href="https://www.twitter.com/LiveArt" class="fa fa-twitter"></a>
<a href="https://www.googleplus.com/LiveArt" class="fa fa-google"></a>
<a href="https://www.linkedin.com/LiveArt" class="fa fa-linkedin"></a>
<a href="https://www.youtibe.com/LiveArt" class="fa fa-youtube"></a>
</div>
</footer>
</body>
</html>


<?php
 
  require 'config.php';


if(isset($_POST["save"]))

{
$user_name=$_SESSION['SESS_USER_NAME'];

$ag = $_POST["age"];
$dob= $_POST["dob"];
$gen = $_POST["gender"];
$art = $_POST["Art"];
$tel = $_POST["tel"];
$des = $_POST["text"];

$sql="UPDATE user SET Age='$ag',DOB='$dob',Gender='$gen',Art_styles='$art',Mobile='$tel',Description='$des' WHERE username='$user_name' ";

if(mysqli_query($con,$sql))
{
echo "success";
}

else

{
  echo "failed";
}

}

mysqli_close($con);


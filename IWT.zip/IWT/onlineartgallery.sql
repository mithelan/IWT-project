SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE `card` (
  `username` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `cname` int(30) NOT NULL,
  `cvv` int(3) NOT NULL,
  `ex_date` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `card` VALUES
('mhd_raleen', 'Mohamed ', 'Raleen', 2147483647, 786, '0000-00-00'),
('ranuladmin', 'Ranul', 'De Silva', 2147483647, 786, '2018-10-23'),
('vythu.sothyartist', 'Vyhari', 'Sothy', 2147483647, 456, '2018-10-31');

CREATE TABLE `feedback` (
  `username` varchar(50) NOT NULL,
  `rate` varchar(50) NOT NULL,
  `improvement` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `following` (
  `username` varchar(50) NOT NULL,
  `artistname` varchar(20) NOT NULL,
  `artistcountry` varchar(20) NOT NULL,
  `followed_on` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`artistname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `following` VALUES
('ranuladmin', 'Luce', 'Slovakia', '2018-10-07');

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` date NOT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `is_artist` tinyint(1) DEFAULT NULL,
  `Age` int(11) NOT NULL,
  `DOB` date NOT NULL DEFAULT '0000-00-00',
  `Gender` varchar(10) NOT NULL,
  `Art_styles` varchar(100) NOT NULL,
  `Mobile` int(10) NOT NULL,
  `Description` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

INSERT INTO `user` VALUES
(8, 'Mohamed', 'Raleen', 'mhd_raleen', 'mhd@gmail.com', 'c4efd5020cb49b9d3257ffa0fbccc0ae', '2018-10-07', 0, 0, 5, '0000-00-00', ' Male', ' Text design', 778864642, 'Hi hello.'),
(9, 'Ranul', 'De Silva', 'ranuladmin', 'ranul@gmail.com', 'a3aca2964e72000eea4c56cb341002a4', '2018-10-07', 1, 0, 0, '0000-00-01', ' ', ' ', 0, ' '),
(10, 'Vyhari', 'Sothy', 'vythu.sothyartist', 'vyhari@gmail.com', 'c4efd5020cb49b9d3257ffa0fbccc0ae', '2018-10-07', 0, 1, 0, '0000-00-00', '', '', 0, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
